package com.esbserviceconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsbServiceConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
